# Third-party notices

The AC EVO inventory and per-car range catalog were generated from an installed
game package by the open-source RaceIQ project at commit
`0bb86a3d3b6a16f2d534bcbecd9c3d21f26dc91c` and are redistributed under the
GNU Affero General Public License v3.0. The application source is distributed
under the same license.

Assetto Corsa, Assetto Corsa EVO, KUNOS Simulazioni, vehicle names, track names
and related trademarks belong to their respective owners. This is an
independent, unofficial fan project and is not affiliated with KUNOS
Simulazioni or 505 Games.
