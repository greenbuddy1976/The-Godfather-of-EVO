#!/usr/bin/env python3
from __future__ import annotations

import csv
import hashlib
import json
import pathlib
import re
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
APP = ROOT / "app" / "src" / "main"
REPORT = ROOT / "build" / "verification-report.json"


def sha256(path: pathlib.Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def main() -> int:
    manifest = (APP / "AndroidManifest.xml").read_text(encoding="utf-8")
    gradle = (ROOT / "app" / "build.gradle.kts").read_text(encoding="utf-8")
    main_activity = (APP / "java/com/greenbuddy/acevosetupengineer/MainActivity.kt").read_text(encoding="utf-8")
    engineering = (APP / "java/com/greenbuddy/acevosetupengineer/domain/EngineeringModel.kt").read_text(encoding="utf-8")
    live = (APP / "java/com/greenbuddy/acevosetupengineer/live/LiveSearch.kt").read_text(encoding="utf-8")
    colors = (APP / "res/values/colors.xml").read_text(encoding="utf-8")
    provenance = json.loads((APP / "assets/data-provenance.json").read_text(encoding="utf-8"))
    ranges = json.loads((APP / "assets/setup-ranges.json").read_text(encoding="utf-8"))
    with (APP / "assets/tracks.csv").open(encoding="utf-8", newline="") as handle:
        tracks = list(csv.DictReader(handle))

    require('applicationId = "com.greenbuddy.acevosetupengineer"' in gradle, "wrong package id")
    require('android:label="The Godfather of EVO"' in manifest, "wrong visible app name")
    require("#000000" in colors and "#FFD400" in colors, "black/yellow palette missing")
    require("Fine-Tuning" in main_activity, "Fine-Tuning dropdown missing")
    require('ALL_FIVE("Alle 5 Setups")' in (APP / "java/com/greenbuddy/acevosetupengineer/domain/Models.kt").read_text(encoding="utf-8"), "five-set package missing")
    require("MAX_ATTEMPTS = 3" in live, "three LIVE attempts missing")
    require("LIVE-SUCHE FEHLGESCHLAGEN NACH 3 VERSUCHEN" in live, "mandatory LIVE failure message missing")
    require("MUSTANG_ID" in engineering and 'value = if (car.id == MUSTANG_ID)' in engineering, "Mustang TC rule missing")
    require(len(ranges) == 68, f"expected 68 car profiles, got {len(ranges)}")
    require(len(tracks) == 25, f"expected 25 track/layout rows, got {len(tracks)}")
    require(68 * 25 * 5 >= 864, "dynamic matrix below historical minimum")

    assets = APP / "assets"
    require(sha256(assets / "setup-ranges.json") == provenance["rangeSha256"], "range hash mismatch")
    require(sha256(assets / "cars.csv") == provenance["carsSha256"], "car hash mismatch")
    require(sha256(assets / "tracks.csv") == provenance["tracksSha256"], "track hash mismatch")

    forbidden_names = re.compile(r"donorCar|donorTrack|fallbackSetup|oldSetup|baselineSetup", re.IGNORECASE)
    for path in ROOT.rglob("*"):
        if path.is_file() and path.suffix.lower() in {".kt", ".kts", ".java"}:
            require(not forbidden_names.search(path.read_text(encoding="utf-8")), f"forbidden setup source in {path}")
        require(path.suffix.lower() not in {".jks", ".keystore", ".carsetup"}, f"private/carrier artifact committed: {path}")

    report = {
        "status": "GEPRUEFT",
        "packageId": "com.greenbuddy.acevosetupengineer",
        "cars": len(ranges),
        "trackLayoutRows": len(tracks),
        "styles": 5,
        "matrixCases": len(ranges) * len(tracks) * 5,
        "liveAttempts": 3,
        "palette": "black/yellow",
        "fineTuningDropdown": True,
        "mustangTcOneOnly": True,
        "forbiddenNumericDonors": False,
        "dataManifest": provenance["manifestVersion"],
    }
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(report, sort_keys=True))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"VERIFY FAILED: {exc}", file=sys.stderr)
        raise
