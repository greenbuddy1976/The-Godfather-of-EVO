package com.greenbuddy.acevosetupengineer

import com.greenbuddy.acevosetupengineer.binary.CarSetupCodec
import com.greenbuddy.acevosetupengineer.domain.CarProfile
import com.greenbuddy.acevosetupengineer.domain.EngineeringModel
import com.greenbuddy.acevosetupengineer.domain.FineTuning
import com.greenbuddy.acevosetupengineer.domain.ParameterRange
import com.greenbuddy.acevosetupengineer.domain.SetupStyle
import com.greenbuddy.acevosetupengineer.domain.TrackProfile
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class FullMatrixTest {
    @Test fun everyCarTrackAndFiveStyleCombinationCalculatesAndSerializes() {
        val assets = File("src/main/assets")
        val root = JSONObject(File(assets, "setup-ranges.json").readText())
        val cars = root.keys().asSequence().map { id ->
            val json = root.getJSONObject(id)
            val ranges = json.keys().asSequence().associateWith { key ->
                if (json.isNull(key)) null else json.getJSONObject(key).let { range ->
                    val sourceMin = range.getDouble("min")
                    val sourceMax = range.getDouble("max")
                    val min = minOf(sourceMin, sourceMax)
                    val max = maxOf(sourceMin, sourceMax)
                    val step = range.optDouble("step", inferStep(min, max)).takeIf { it > 0.0 } ?: inferStep(min, max)
                    ParameterRange(min, max, step)
                }
            }
            CarProfile(id, id, ranges)
        }.toList()
        val tracks = File(assets, "tracks.csv").readLines().drop(1).map { line ->
            val p = line.split(',', limit = 5)
            TrackProfile(p[3], p[1], p[2], .55, .50, .65, .70, .65)
        }

        assertEquals(68, cars.size)
        assertEquals(25, tracks.size)
        val model = EngineeringModel()
        var cases = 0
        for (car in cars) for (track in tracks) for (style in SetupStyle.entries) {
            val values = model.calculate(car, track, style, FineTuning.AUTO)
            model.validate(car, values)
            val bytes = CarSetupCodec.encode(car, values)
            assertTrue(CarSetupCodec.isValidWire(bytes))
            assertTrue(CarSetupCodec.validateIdentity(bytes, car.id))
            cases++
        }
        assertEquals(68 * 25 * 5, cases)
        assertTrue(cases >= 864)
    }

    private fun inferStep(min: Double, max: Double): Double {
        val span = max - min
        return when {
            span <= 0.1 -> 0.01
            span <= 1.0 -> 0.05
            span <= 20.0 -> 1.0
            span <= 200.0 -> 5.0
            span <= 2_000.0 -> 100.0
            else -> 1_000.0
        }
    }
}
