package com.greenbuddy.acevosetupengineer

import com.greenbuddy.acevosetupengineer.domain.CarProfile
import com.greenbuddy.acevosetupengineer.domain.EngineeringModel
import com.greenbuddy.acevosetupengineer.domain.FineTuning
import com.greenbuddy.acevosetupengineer.domain.OutputMode
import com.greenbuddy.acevosetupengineer.domain.ParameterRange
import com.greenbuddy.acevosetupengineer.domain.SetupSelection
import com.greenbuddy.acevosetupengineer.domain.SetupStyle
import com.greenbuddy.acevosetupengineer.domain.TrackProfile
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class EngineeringModelTest {
    private val track = TrackProfile("spa", "Spa-Francorchamps", "GP", 0.7, 0.5, 0.7, 0.7, 0.8)
    private val ranges = EngineeringModel.OUTPUT_ORDER.associateWith { ParameterRange(0.0, 10.0, 1.0) }

    @Test fun allFiveStylesAreGeneratedAndDiffer() {
        val car = CarProfile("test_car", "Test Car", ranges)
        val variants = EngineeringModel().generate(
            SetupSelection(car, track, FineTuning.AUTO, OutputMode.ALL_FIVE),
            liveFailedAfterThreeAttempts = false,
        )
        assertEquals(5, variants.size)
        assertEquals(5, variants.map { it.style }.distinct().size)
        assertTrue(variants.all { it.values.isNotEmpty() })
        assertTrue(variants.map { it.values }.distinct().size >= 4)
    }

    @Test fun tcOneIsReservedForMustang() {
        val model = EngineeringModel()
        val tcRanges = mapOf("tc" to ParameterRange(0.0, 12.0, 1.0), "fuel" to ParameterRange(1.0, 100.0, 1.0))
        val mustang = CarProfile(EngineeringModel.MUSTANG_ID, "Ford Mustang GT3", tcRanges)
        val other = CarProfile("ferrari_296_gt3", "Ferrari 296 GT3", tcRanges)
        SetupStyle.entries.forEach { style ->
            assertEquals(1.0, model.calculate(mustang, track, style, FineTuning.AUTO)["tc"]!!, 0.0)
            assertNotEquals(1.0, model.calculate(other, track, style, FineTuning.AUTO)["tc"]!!, 0.0)
        }
    }

    @Test fun everyValueIsRangeAndStepValid() {
        val car = CarProfile("test_car", "Test Car", ranges)
        val model = EngineeringModel()
        SetupStyle.entries.forEach { style ->
            val values = model.calculate(car, track, style, FineTuning.MORE_STABILITY)
            model.validate(car, values)
        }
    }
}
