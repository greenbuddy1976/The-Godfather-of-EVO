package com.greenbuddy.acevosetupengineer

import com.greenbuddy.acevosetupengineer.domain.CarProfile
import com.greenbuddy.acevosetupengineer.domain.FineTuning
import com.greenbuddy.acevosetupengineer.domain.OutputMode
import com.greenbuddy.acevosetupengineer.domain.SetupSelection
import com.greenbuddy.acevosetupengineer.domain.TrackProfile
import com.greenbuddy.acevosetupengineer.live.LiveCandidate
import com.greenbuddy.acevosetupengineer.live.LiveSearchCoordinator
import com.greenbuddy.acevosetupengineer.live.LiveSearchResult
import com.greenbuddy.acevosetupengineer.live.ProviderOutcome
import com.greenbuddy.acevosetupengineer.live.SetupProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LiveSearchCoordinatorTest {
    private val selection = SetupSelection(
        CarProfile("ford_mustang_gt3", "Ford Mustang GT3", emptyMap()),
        TrackProfile("spa", "Spa-Francorchamps", "GP", .7, .5, .7, .7, .8),
        FineTuning.AUTO,
        OutputMode.ALL_FIVE,
    )

    @Test fun retriesCompleteRoundExactlyThreeTimes() {
        val failing = FakeProvider(ProviderOutcome.TechnicalFailure("offline"))
        val successful = FakeProvider(ProviderOutcome.Success(emptyList()))
        val result = LiveSearchCoordinator(listOf(failing, successful)).search(selection)
        assertTrue(result is LiveSearchResult.TechnicalFailure)
        assertEquals(3, failing.calls)
        assertEquals(3, successful.calls)
    }

    @Test fun technicallySuccessfulEmptyRoundIsNoExactNotFailure() {
        val result = LiveSearchCoordinator(listOf(FakeProvider(ProviderOutcome.Success(emptyList())))).search(selection)
        assertTrue(result is LiveSearchResult.NoExact)
        assertEquals(1, (result as LiveSearchResult.NoExact).attempts)
    }

    private class FakeProvider(private val outcome: ProviderOutcome) : SetupProvider {
        override val name = "fake"
        var calls = 0
        override fun search(selection: SetupSelection): ProviderOutcome { calls++; return outcome }
        override fun download(candidate: LiveCandidate): ByteArray = byteArrayOf()
    }
}
