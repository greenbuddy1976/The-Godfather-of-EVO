package com.greenbuddy.acevosetupengineer

import com.greenbuddy.acevosetupengineer.binary.CarSetupCodec
import com.greenbuddy.acevosetupengineer.domain.CarProfile
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CarSetupCodecTest {
    @Test fun roundTripPreservesIdentityAndKnownFloat() {
        val car = CarProfile("ford_mustang_gt3", "Ford Mustang GT3", emptyMap())
        val bytes = CarSetupCodec.encode(car, mapOf("brakeBias" to 55.4, "tc" to 1.0, "fuel" to 15.0))
        assertTrue(CarSetupCodec.isValidWire(bytes))
        assertTrue(CarSetupCodec.validateIdentity(bytes, car.id))
        assertEquals(55.4, CarSetupCodec.readFloat(bytes, 1, 3, 1)!!, 0.001)
        assertEquals(1.0, CarSetupCodec.readFloat(bytes, 5, 1)!!, 0.001)
        assertEquals(15.0, CarSetupCodec.readFloat(bytes, 7, 1)!!, 0.001)
    }
}
