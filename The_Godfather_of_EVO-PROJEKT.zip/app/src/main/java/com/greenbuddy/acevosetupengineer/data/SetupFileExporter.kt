package com.greenbuddy.acevosetupengineer.data

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import com.greenbuddy.acevosetupengineer.binary.CarSetupCodec
import com.greenbuddy.acevosetupengineer.domain.SetupOrigin
import com.greenbuddy.acevosetupengineer.domain.SetupSelection
import com.greenbuddy.acevosetupengineer.domain.SetupVariant
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SetupFileExporter(private val context: Context) {
    fun write(selection: SetupSelection, variants: List<SetupVariant>): List<File> {
        val root = requireNotNull(context.getExternalFilesDir("setups"))
        val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.ROOT).format(Date())
        val directory = File(root, "${safe(selection.car.name)}_${safe(selection.track.name)}_$stamp")
        require(directory.mkdirs() || directory.isDirectory)
        return variants.map { variant ->
            val bytes = if (variant.origin == SetupOrigin.LIVE_EXACT) {
                val exact = requireNotNull(variant.exactBytes) { "LIVE-EXACT bytes are missing" }
                require(CarSetupCodec.isValidWire(exact)) { "LIVE-EXACT wire structure is invalid" }
                require(CarSetupCodec.validateIdentity(exact, selection.car.id)) {
                    "LIVE-EXACT vehicle identity does not match"
                }
                exact
            } else {
                require(variant.values.isNotEmpty()) { "Engineering setup has no calculated values" }
                CarSetupCodec.encode(selection.car, variant.values)
            }
            val file = File(
                directory,
                "${safe(selection.car.name)}_${safe(selection.track.name)}_${safe(selection.track.layout)}_${variant.style.fileToken}.carsetup",
            )
            file.writeBytes(bytes)
            require(file.length() == bytes.size.toLong()) { "File write verification failed" }
            require(CarSetupCodec.isValidWire(file.readBytes())) { "Round-trip parse failed" }
            file
        }
    }

    fun share(files: List<File>): Intent {
        val uris = ArrayList(files.map { file ->
            FileProvider.getUriForFile(context, "${context.packageName}.files", file)
        })
        return Intent(Intent.ACTION_SEND_MULTIPLE).apply {
            type = "application/octet-stream"
            putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
            putExtra(Intent.EXTRA_SUBJECT, "The Godfather of EVO – Setups")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    private fun safe(value: String): String = value
        .replace(Regex("[^A-Za-z0-9._-]+"), "_")
        .trim('_')
        .take(72)
}
