package com.greenbuddy.acevosetupengineer.live

import com.greenbuddy.acevosetupengineer.domain.SetupSelection
import com.greenbuddy.acevosetupengineer.domain.SetupStyle
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.Locale

data class LiveCandidate(
    val provider: String,
    val title: String,
    val car: String,
    val trackAndLayout: String,
    val gameVersion: String?,
    val detailUrl: String,
    val downloadUrl: String,
)

sealed interface ProviderOutcome {
    data class Success(val candidates: List<LiveCandidate>) : ProviderOutcome
    data class TechnicalFailure(val message: String) : ProviderOutcome
}

interface SetupProvider {
    val name: String
    fun search(selection: SetupSelection): ProviderOutcome
    fun download(candidate: LiveCandidate): ByteArray
}

sealed interface LiveSearchResult {
    data class Exact(val byStyle: Map<SetupStyle, Pair<String, ByteArray>>, val attempts: Int) : LiveSearchResult
    data class NoExact(val attempts: Int) : LiveSearchResult
    data class TechnicalFailure(val attempts: Int, val errors: List<String>) : LiveSearchResult
}

class LiveSearchCoordinator(
    private val providers: List<SetupProvider>,
    private val onProgress: (String) -> Unit = {},
) {
    init { require(providers.isNotEmpty()) }

    fun search(selection: SetupSelection): LiveSearchResult {
        val finalErrors = mutableListOf<String>()
        repeat(MAX_ATTEMPTS) { index ->
            val attempt = index + 1
            onProgress("LIVE-SUCHE – vollständiger Versuch $attempt/$MAX_ATTEMPTS")
            val outcomes = providers.map { provider ->
                onProgress("Versuch $attempt/$MAX_ATTEMPTS: ${provider.name}")
                provider to runCatching { provider.search(selection) }
                    .getOrElse { ProviderOutcome.TechnicalFailure(it.message ?: it.javaClass.simpleName) }
            }
            val failures = outcomes.mapNotNull { (provider, outcome) ->
                (outcome as? ProviderOutcome.TechnicalFailure)?.let { "${provider.name}: ${it.message}" }
            }
            if (failures.isNotEmpty()) {
                finalErrors.clear()
                finalErrors.addAll(failures)
                return@repeat
            }

            val exact = outcomes.flatMap { (provider, outcome) ->
                (outcome as ProviderOutcome.Success).candidates
                    .filter { ExactMatcher.matches(selection, it) }
                    .mapNotNull { candidate ->
                        runCatching { candidate to provider.download(candidate) }.getOrNull()
                    }
            }
            if (exact.isEmpty()) return LiveSearchResult.NoExact(attempt)

            val styled = linkedMapOf<SetupStyle, Pair<String, ByteArray>>()
            for ((candidate, bytes) in exact) {
                val style = StyleClassifier.classify(candidate.title) ?: continue
                styled.putIfAbsent(style, "${candidate.provider}: ${candidate.title}" to bytes)
            }
            // An exact file without a clear driving-style label is still useful,
            // but only as the neutral Stable & Fast variant; it is never used as
            // a numeric donor for another variant.
            if (styled.isEmpty()) {
                val (candidate, bytes) = exact.first()
                styled[SetupStyle.STABLE_FAST] = "${candidate.provider}: ${candidate.title}" to bytes
            }
            return LiveSearchResult.Exact(styled, attempt)
        }
        onProgress("LIVE-SUCHE FEHLGESCHLAGEN NACH 3 VERSUCHEN")
        return LiveSearchResult.TechnicalFailure(MAX_ATTEMPTS, finalErrors)
    }

    companion object { const val MAX_ATTEMPTS = 3 }
}

object ExactMatcher {
    fun matches(selection: SetupSelection, candidate: LiveCandidate): Boolean {
        val wantedCar = canonical(selection.car.name)
        val candidateCar = canonical(candidate.car)
        if (wantedCar != candidateCar && canonical(selection.car.id) != candidateCar) return false

        val wantedTrack = canonical("${selection.track.name} ${selection.track.layout}")
        val candidateTrack = canonical(candidate.trackAndLayout)
        if (!layoutEquivalent(wantedTrack, candidateTrack)) return false

        val version = candidate.gameVersion ?: return true
        fun majorMinor(value: String) = value.split('.').take(2).joinToString(".")
        return majorMinor(version) == majorMinor(selection.gameVersion)
    }

    internal fun canonical(value: String): String = value
        .lowercase(Locale.ROOT)
        .replace("nürburgring", "nurburgring")
        .replace("grand prix", "gp")
        .replace("evo ii", "evo 2")
        .replace("evo2", "evo 2")
        .replace("911 (992)", "992")
        .replace(Regex("[^a-z0-9]+"), " ")
        .trim()
        .replace(Regex("\\s+"), " ")

    private fun layoutEquivalent(wanted: String, candidate: String): Boolean {
        if (wanted == candidate) return true
        val aliases = mapOf(
            "nurburgring nordschleife 24h" to setOf("nurburgring 24h", "nordschleife 24h"),
            "watkins glen gp" to setOf("watkins glen gp", "watkins glen grand prix"),
            "circuit of the americas gp" to setOf("cota gp", "circuit of the americas gp"),
        )
        return aliases[wanted]?.contains(candidate) == true
    }
}

object StyleClassifier {
    fun classify(title: String): SetupStyle? {
        val text = title.lowercase(Locale.ROOT)
        return when {
            listOf("hotlap", "hot lap", "qualifying", "quali", "attack").any(text::contains) -> SetupStyle.HOTLAP_ATTACK
            listOf("endurance", "longrun", "long run").any(text::contains) -> SetupStyle.STABLE_LONGRUN
            listOf("beginner", "easy", "safe").any(text::contains) -> SetupStyle.SAFE
            text.contains("stable") && text.contains("fast") -> SetupStyle.STABLE_FAST
            listOf("race", "fast").any(text::contains) -> SetupStyle.FAST_CONTROL
            else -> null
        }
    }
}

abstract class HttpSetupProvider : SetupProvider {
    protected fun getText(url: String): String = String(getBytes(url), StandardCharsets.UTF_8)

    protected fun getBytes(url: String): ByteArray {
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.connectTimeout = 12_000
        connection.readTimeout = 18_000
        connection.instanceFollowRedirects = true
        connection.setRequestProperty("User-Agent", "The-Godfather-of-EVO/3.0 Android")
        connection.setRequestProperty("Accept", "*/*")
        try {
            val code = connection.responseCode
            require(code in 200..299) { "HTTP $code" }
            val out = ByteArrayOutputStream()
            connection.inputStream.use { input ->
                val buffer = ByteArray(8_192)
                var total = 0
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    total += count
                    require(total <= MAX_DOWNLOAD_BYTES) { "response exceeds size limit" }
                    out.write(buffer, 0, count)
                }
            }
            return out.toByteArray()
        } finally {
            connection.disconnect()
        }
    }

    companion object { private const val MAX_DOWNLOAD_BYTES = 2 * 1024 * 1024 }
}

class SetupsMarketProvider : HttpSetupProvider() {
    override val name = "SetupsMarket"

    override fun search(selection: SetupSelection): ProviderOutcome = try {
        val html = getText(HOME)
        val candidates = CARD.findAll(html).map { match ->
            val id = match.groupValues[1]
            LiveCandidate(
                provider = name,
                title = clean(match.groupValues[2]),
                car = clean(match.groupValues[3]),
                trackAndLayout = clean(match.groupValues[4]),
                gameVersion = null,
                detailUrl = "$HOME/setup/$id",
                downloadUrl = "$HOME/setup/$id/download",
            )
        }.toList()
        ProviderOutcome.Success(candidates)
    } catch (e: Exception) {
        ProviderOutcome.TechnicalFailure(e.message ?: "unbekannter Netzwerkfehler")
    }

    override fun download(candidate: LiveCandidate): ByteArray {
        val detail = getText(candidate.detailUrl)
        require(detail.contains(candidate.car, ignoreCase = true)) { "car identity changed" }
        require(detail.contains(candidate.trackAndLayout, ignoreCase = true)) { "track identity changed" }
        return getBytes(candidate.downloadUrl).also { require(it.size in 32..65_536) { "invalid setup size" } }
    }

    private fun clean(text: String): String = text
        .replace(Regex("<[^>]+>"), " ")
        .replace("&amp;", "&")
        .replace("&#x27;", "'")
        .replace(Regex("\\s+"), " ")
        .trim()

    companion object {
        private const val HOME = "https://setupsmarket.com"
        private val CARD = Regex(
            "href=\"/setup/([0-9a-f-]{36})\"[^>]*>(.*?)</a>\\s*</h3>\\s*<p[^>]*>(.*?)</p>\\s*<p[^>]*>(.*?)</p>",
            setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL),
        )
    }
}

class MellonRacingProvider : HttpSetupProvider() {
    override val name = "Mellon Racing"

    override fun search(selection: SetupSelection): ProviderOutcome = try {
        val html = getText(HOME)
        val wanted = "${selection.car.name} ${selection.track.name} ${selection.track.layout}"
        val candidates = DIRECT_LINK.findAll(html).mapNotNull { match ->
            val href = match.groupValues[1]
            val context = match.groupValues[2]
            if (!tokensPresent(context, wanted)) null else LiveCandidate(
                provider = name,
                title = "Mellon Racing Free Tune",
                car = selection.car.name,
                trackAndLayout = "${selection.track.name} ${selection.track.layout}",
                gameVersion = null,
                detailUrl = HOME,
                downloadUrl = URI(HOME).resolve(href).toString(),
            )
        }.toList()
        ProviderOutcome.Success(candidates)
    } catch (e: Exception) {
        ProviderOutcome.TechnicalFailure(e.message ?: "unbekannter Netzwerkfehler")
    }

    override fun download(candidate: LiveCandidate): ByteArray = getBytes(candidate.downloadUrl)

    private fun tokensPresent(text: String, wanted: String): Boolean {
        val haystack = ExactMatcher.canonical(text)
        return ExactMatcher.canonical(wanted).split(' ').filter { it.length > 2 }.all(haystack::contains)
    }

    companion object {
        private const val HOME = "https://mellonracing.com/dashboard/tunes"
        private val DIRECT_LINK = Regex(
            "href=\"([^\"]+\\.carsetup[^\"]*)\"(.{0,700})",
            setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL),
        )
    }
}

class GitHubPublicProvider : HttpSetupProvider() {
    override val name = "GitHub Public"

    override fun search(selection: SetupSelection): ProviderOutcome = try {
        val query = URLEncoder.encode(
            "\"${selection.car.name}\" \"${selection.track.name}\" extension:carsetup",
            StandardCharsets.UTF_8.name(),
        )
        val html = getText("https://github.com/search?q=$query&type=code")
        val candidates = BLOB.findAll(html).map { match ->
            val blob = match.groupValues[1]
            val raw = "https://raw.githubusercontent.com/" + blob
                .removePrefix("/")
                .replaceFirst("/blob/", "/")
            LiveCandidate(
                provider = name,
                title = "GitHub .carsetup",
                car = selection.car.name,
                trackAndLayout = "${selection.track.name} ${selection.track.layout}",
                gameVersion = null,
                detailUrl = "https://github.com$blob",
                downloadUrl = raw,
            )
        }.toList()
        ProviderOutcome.Success(candidates)
    } catch (e: Exception) {
        ProviderOutcome.TechnicalFailure(e.message ?: "unbekannter Netzwerkfehler")
    }

    override fun download(candidate: LiveCandidate): ByteArray = getBytes(candidate.downloadUrl)

    companion object {
        private val BLOB = Regex("href=\"([^\"]+/blob/[^\"]+\\.carsetup)\"", RegexOption.IGNORE_CASE)
    }
}
