package com.greenbuddy.acevosetupengineer.domain

import java.math.BigDecimal
import java.math.RoundingMode
import kotlin.math.abs
import kotlin.math.round

/**
 * Deterministic engineering model. It never reads numeric values from a
 * downloaded .carsetup. Every output is derived from the selected car range,
 * exact layout profile, style and fine-tuning, then quantized and clamped.
 */
class EngineeringModel {
    fun generate(
        selection: SetupSelection,
        liveFailedAfterThreeAttempts: Boolean,
        exactByStyle: Map<SetupStyle, Pair<String, ByteArray>> = emptyMap(),
    ): List<SetupVariant> = selection.outputMode.styles().map { style ->
        val exact = exactByStyle[style]
        if (exact != null) {
            SetupVariant(
                style = style,
                values = linkedMapOf(),
                origin = SetupOrigin.LIVE_EXACT,
                sourceLabel = exact.first,
                exactBytes = exact.second,
            )
        } else {
            SetupVariant(
                style = style,
                values = calculate(selection.car, selection.track, style, selection.fineTuning),
                origin = if (liveFailedAfterThreeAttempts) {
                    SetupOrigin.LIVE_UNVERIFIED_ENGINEERING_MODEL
                } else {
                    SetupOrigin.ENGINEERING_MODEL
                },
            )
        }
    }

    fun calculate(
        car: CarProfile,
        track: TrackProfile,
        style: SetupStyle,
        fineTuning: FineTuning,
    ): LinkedHashMap<String, Double> {
        val output = linkedMapOf<String, Double>()
        for (key in OUTPUT_ORDER) {
            val range = car.ranges[key] ?: continue // verified: regulator is unavailable for this car
            val normalized = normalizedTarget(key, track, style, fineTuning)
            var value = range.quantize(normalized)

            // Explicit user rule: TC 1 is reserved for the Ford Mustang GT3.
            if (key == "tc") {
                value = if (car.id == MUSTANG_ID) {
                    range.closestValid(1.0)
                } else if (abs(value - 1.0) < EPSILON) {
                    when {
                        range.max >= 2.0 -> range.closestValid(2.0)
                        range.min <= 0.0 -> range.closestValid(0.0)
                        else -> value
                    }
                } else value
            }
            output[key] = value
        }
        validate(car, output)
        return output
    }

    fun validate(car: CarProfile, values: Map<String, Double>) {
        require(values.isNotEmpty()) { "No adjustable parameters for ${car.id}" }
        for ((key, value) in values) {
            val range = requireNotNull(car.ranges[key]) { "Unknown or unavailable parameter: $key" }
            require(value.isFinite()) { "$key is not finite" }
            require(value >= range.min - EPSILON && value <= range.max + EPSILON) {
                "$key=$value outside ${range.min}..${range.max}"
            }
            val clicks = (value - range.min) / range.step
            require(abs(clicks - round(clicks)) < 1e-5 || abs(value - range.max) < EPSILON) {
                "$key=$value is not aligned to step ${range.step}"
            }
        }
    }

    private fun normalizedTarget(
        key: String,
        track: TrackProfile,
        style: SetupStyle,
        fine: FineTuning,
    ): Double {
        val pace = when (style) {
            SetupStyle.HOTLAP_ATTACK -> 0.82
            SetupStyle.FAST_CONTROL -> 0.66
            SetupStyle.STABLE_LONGRUN -> 0.49
            SetupStyle.SAFE -> 0.31
            SetupStyle.STABLE_FAST -> 0.59
        }
        val stability = when (style) {
            SetupStyle.HOTLAP_ATTACK -> 0.30
            SetupStyle.FAST_CONTROL -> 0.47
            SetupStyle.STABLE_LONGRUN -> 0.70
            SetupStyle.SAFE -> 0.88
            SetupStyle.STABLE_FAST -> 0.73
        }
        val fineDelta = when (fine) {
            FineTuning.AUTO -> 0.0
            FineTuning.MORE_ROTATION -> 0.07
            FineTuning.MORE_STABILITY -> -0.07
            FineTuning.KERB_SAFE -> -0.04
            FineTuning.TYRE_SAVING -> -0.05
        }
        return when (key) {
            "frontLeftTyrePressure", "frontRightTyrePressure" ->
                0.47 + 0.08 * track.tyreStress - 0.05 * track.bumpiness - fineDelta * 0.25
            "rearLeftTyrePressure", "rearRightTyrePressure" ->
                0.45 + 0.07 * track.tyreStress - 0.04 * track.bumpiness + fineDelta * 0.20
            "frontCamber" -> 0.66 + 0.16 * track.downforce + pace * 0.08
            "rearCamber" -> 0.58 + 0.12 * track.downforce + pace * 0.06
            "frontToe" -> 0.48 + fineDelta + (pace - stability) * 0.05
            "rearToe" -> 0.54 - fineDelta + stability * 0.08
            "tc", "tc2" -> stability * 0.62 + track.traction * 0.20
            "abs" -> stability * 0.55 + track.braking * 0.23
            "engineMap" -> pace
            "fuel" -> when (style) {
                SetupStyle.HOTLAP_ATTACK -> 0.04
                SetupStyle.FAST_CONTROL -> 0.12
                SetupStyle.STABLE_FAST -> 0.18
                SetupStyle.STABLE_LONGRUN -> 0.34
                SetupStyle.SAFE -> 0.25
            }
            "frontARB" -> 0.44 + pace * 0.30 + track.downforce * 0.13 - track.bumpiness * 0.25 + fineDelta
            "rearARB" -> 0.39 + pace * 0.27 + track.downforce * 0.10 - track.bumpiness * 0.28 + fineDelta * 1.35
            "steerRatio" -> 0.55 - pace * 0.18 + stability * 0.12
            "brakeBias" -> 0.47 + stability * 0.16 + track.braking * 0.09 - fineDelta * 0.40
            "brakePressure" -> 0.48 + pace * 0.30 - track.bumpiness * 0.08
            "diffPower" -> 0.43 + pace * 0.26 - track.traction * 0.10 - fineDelta * 0.35
            "diffCoast" -> 0.35 + stability * 0.27 + track.braking * 0.09 - fineDelta * 0.45
            "diffPreload" -> 0.35 + stability * 0.22 + pace * 0.12
            "frontSpringRate" -> 0.43 + pace * 0.26 + track.downforce * 0.17 - track.bumpiness * 0.30
            "rearSpringRate" -> 0.40 + pace * 0.24 + track.downforce * 0.15 - track.bumpiness * 0.32 + fineDelta
            "frontBump", "rearBump" -> 0.39 + pace * 0.20 - track.bumpiness * 0.23
            "frontRebound", "rearRebound" -> 0.45 + pace * 0.23 - track.bumpiness * 0.16
            "frontRideHeight" -> 0.30 + track.bumpiness * 0.48 - track.downforce * 0.12
            "rearRideHeight" -> 0.36 + track.bumpiness * 0.45 - track.downforce * 0.08
            "frontWing" -> 0.30 + track.downforce * 0.55 + stability * 0.08
            "rearWing" -> 0.34 + track.downforce * 0.51 + stability * 0.13 - fineDelta * 0.20
            else -> 0.5
        }.coerceIn(0.0, 1.0)
    }

    private fun ParameterRange.quantize(normalized: Double): Double =
        closestValid(min + (max - min) * normalized.coerceIn(0.0, 1.0))

    private fun ParameterRange.closestValid(target: Double): Double {
        val clicks = round((target.coerceIn(min, max) - min) / step)
        val value = (min + clicks * step).coerceIn(min, max)
        return BigDecimal.valueOf(value).setScale(6, RoundingMode.HALF_UP).stripTrailingZeros().toDouble()
    }

    companion object {
        const val MUSTANG_ID = "ford_mustang_gt3"
        private const val EPSILON = 1e-6

        val OUTPUT_ORDER = listOf(
            // Tires
            "frontLeftTyrePressure", "frontRightTyrePressure", "rearLeftTyrePressure", "rearRightTyrePressure",
            "frontCamber", "rearCamber", "frontToe", "rearToe",
            // Electronics
            "tc", "tc2", "abs", "engineMap",
            // Fuel
            "fuel",
            // Mechanics / suspension
            "frontARB", "rearARB", "steerRatio", "brakeBias", "brakePressure",
            "diffPower", "diffCoast", "diffPreload", "frontSpringRate", "rearSpringRate",
            // Dampers
            "frontBump", "frontRebound", "rearBump", "rearRebound",
            // Aero
            "frontRideHeight", "rearRideHeight", "frontWing", "rearWing",
        )
    }
}
