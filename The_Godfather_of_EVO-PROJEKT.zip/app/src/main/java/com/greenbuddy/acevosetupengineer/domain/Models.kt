package com.greenbuddy.acevosetupengineer.domain

data class ParameterRange(
    val min: Double,
    val max: Double,
    val step: Double,
) {
    init {
        require(min <= max) { "min must not exceed max" }
        require(step > 0.0) { "step must be positive" }
    }
}

data class CarProfile(
    val id: String,
    val name: String,
    val ranges: Map<String, ParameterRange?>,
)

data class TrackProfile(
    val id: String,
    val name: String,
    val layout: String,
    val downforce: Double,
    val bumpiness: Double,
    val traction: Double,
    val braking: Double,
    val tyreStress: Double,
)

enum class SetupStyle(val displayName: String, val fileToken: String) {
    HOTLAP_ATTACK("Michael Schumacher – Sehr schnell", "MICHAEL_SCHUMACHER"),
    FAST_CONTROL("Walter Röhrl – Schnell", "WALTER_ROEHRL"),
    STABLE_LONGRUN("Dieter Düsel – Normal", "DIETER_DUESEL"),
    SAFE("Oma Hertha – Entspannt", "OMA_HERTHA"),
    STABLE_FAST("Stabil & Schnell", "STABIL_UND_SCHNELL"),
}

enum class FineTuning(val displayName: String) {
    AUTO("Automatisch / ausgewogen"),
    MORE_ROTATION("Mehr Rotation"),
    MORE_STABILITY("Mehr Stabilität"),
    KERB_SAFE("Kerb-sicher"),
    TYRE_SAVING("Reifenschonend"),
}

enum class OutputMode(val displayName: String) {
    ALL_FIVE("Alle 5 Setups"),
    HOTLAP_ONLY("Nur Michael Schumacher"),
    FAST_ONLY("Nur Walter Röhrl"),
    LONGRUN_ONLY("Nur Dieter Düsel"),
    SAFE_ONLY("Nur Oma Hertha"),
    STABLE_FAST_ONLY("Nur Stabil & Schnell"),
}

enum class SetupOrigin { LIVE_EXACT, ENGINEERING_MODEL, LIVE_UNVERIFIED_ENGINEERING_MODEL }

data class SetupVariant(
    val style: SetupStyle,
    val values: LinkedHashMap<String, Double>,
    val origin: SetupOrigin,
    val sourceLabel: String? = null,
    val exactBytes: ByteArray? = null,
)

data class SetupSelection(
    val car: CarProfile,
    val track: TrackProfile,
    val fineTuning: FineTuning,
    val outputMode: OutputMode,
    val gameVersion: String = "0.8.1",
)

fun OutputMode.styles(): List<SetupStyle> = when (this) {
    OutputMode.ALL_FIVE -> SetupStyle.entries
    OutputMode.HOTLAP_ONLY -> listOf(SetupStyle.HOTLAP_ATTACK)
    OutputMode.FAST_ONLY -> listOf(SetupStyle.FAST_CONTROL)
    OutputMode.LONGRUN_ONLY -> listOf(SetupStyle.STABLE_LONGRUN)
    OutputMode.SAFE_ONLY -> listOf(SetupStyle.SAFE)
    OutputMode.STABLE_FAST_ONLY -> listOf(SetupStyle.STABLE_FAST)
}
