package com.greenbuddy.acevosetupengineer

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.greenbuddy.acevosetupengineer.data.InventoryRepository
import com.greenbuddy.acevosetupengineer.data.SetupFileExporter
import com.greenbuddy.acevosetupengineer.domain.CarProfile
import com.greenbuddy.acevosetupengineer.domain.EngineeringModel
import com.greenbuddy.acevosetupengineer.domain.FineTuning
import com.greenbuddy.acevosetupengineer.domain.OutputMode
import com.greenbuddy.acevosetupengineer.domain.SetupOrigin
import com.greenbuddy.acevosetupengineer.domain.SetupSelection
import com.greenbuddy.acevosetupengineer.domain.SetupStyle
import com.greenbuddy.acevosetupengineer.domain.SetupVariant
import com.greenbuddy.acevosetupengineer.domain.TrackProfile
import com.greenbuddy.acevosetupengineer.live.GitHubPublicProvider
import com.greenbuddy.acevosetupengineer.live.LiveSearchCoordinator
import com.greenbuddy.acevosetupengineer.live.LiveSearchResult
import com.greenbuddy.acevosetupengineer.live.MellonRacingProvider
import com.greenbuddy.acevosetupengineer.live.SetupsMarketProvider
import java.io.File
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private val yellow = Color.rgb(255, 212, 0)
    private val surface = Color.rgb(17, 17, 17)
    private lateinit var cars: List<CarProfile>
    private lateinit var tracks: List<TrackProfile>
    private lateinit var carSpinner: Spinner
    private lateinit var trackSpinner: Spinner
    private lateinit var outputSpinner: Spinner
    private lateinit var fineSpinner: Spinner
    private lateinit var generateButton: Button
    private lateinit var shareButton: Button
    private lateinit var progress: ProgressBar
    private lateinit var status: TextView
    private lateinit var result: TextView
    private var latestFiles: List<File> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        val repository = InventoryRepository(this)
        cars = repository.loadCars()
        tracks = repository.loadTracks()
        setContentView(buildUi())
        bindData()
    }

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(28))
            setBackgroundColor(Color.BLACK)
        }
        root.addView(TextView(this).apply {
            text = "THE GODFATHER OF EVO"
            setTextColor(yellow)
            textSize = 25f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_HORIZONTAL
        })
        root.addView(TextView(this).apply {
            text = "Assetto Corsa EVO Setup Engineer"
            setTextColor(Color.WHITE)
            textSize = 15f
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, dp(4), 0, dp(20))
        })

        carSpinner = addSpinner(root, "Fahrzeug")
        trackSpinner = addSpinner(root, "Strecke & exaktes Layout")
        outputSpinner = addSpinner(root, "Setup-Paket")
        fineSpinner = addSpinner(root, "Fine-Tuning")

        generateButton = Button(this).apply {
            text = "LIVE SUCHEN & SETUPS ERSTELLEN"
            setTextColor(Color.BLACK)
            setBackgroundColor(yellow)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(8), dp(12), dp(8), dp(12))
            setOnClickListener { generate() }
        }
        root.addView(generateButton, marginParams(top = 18))

        progress = ProgressBar(this).apply {
            isIndeterminate = true
            visibility = View.GONE
            indeterminateTintList = android.content.res.ColorStateList.valueOf(yellow)
        }
        root.addView(progress, marginParams(top = 12, gravity = Gravity.CENTER_HORIZONTAL))

        status = TextView(this).apply {
            setTextColor(yellow)
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, dp(8), 0, dp(8))
            text = "Bereit – LIVE-Suche läuft vor jeder Berechnung."
        }
        root.addView(status)

        shareButton = Button(this).apply {
            text = "SETUPS TEILEN / SPEICHERN"
            setTextColor(yellow)
            setBackgroundColor(surface)
            isEnabled = false
            visibility = View.GONE
            setOnClickListener {
                startActivity(Intent.createChooser(SetupFileExporter(this@MainActivity).share(latestFiles), "Setups speichern"))
            }
        }
        root.addView(shareButton, marginParams(top = 8))

        result = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 14f
            setLineSpacing(0f, 1.2f)
            setPadding(dp(12), dp(14), dp(12), dp(14))
            setBackgroundColor(surface)
            text = "Ausgabe-Reihenfolge: Reifen → Elektronik → Kraftstoff → Mechanik/Fahrwerk → Dämpfer → Aero"
        }
        root.addView(result, marginParams(top = 14))

        root.addView(TextView(this).apply {
            text = "ENGINEERING MODEL · keine alten Setups · keine Spenderfahrzeuge\n© Greenbuddy1976"
            setTextColor(Color.LTGRAY)
            textSize = 11f
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, dp(22), 0, 0)
        })
        return ScrollView(this).apply { addView(root) }
    }

    private fun bindData() {
        carSpinner.adapter = YellowAdapter(cars.map { it.name })
        trackSpinner.adapter = YellowAdapter(tracks.map { "${it.name} – ${it.layout}" })
        outputSpinner.adapter = YellowAdapter(OutputMode.entries.map { it.displayName })
        fineSpinner.adapter = YellowAdapter(FineTuning.entries.map { it.displayName })
    }

    private fun generate() {
        val selection = SetupSelection(
            car = cars[carSpinner.selectedItemPosition],
            track = tracks[trackSpinner.selectedItemPosition],
            fineTuning = FineTuning.entries[fineSpinner.selectedItemPosition],
            outputMode = OutputMode.entries[outputSpinner.selectedItemPosition],
        )
        setBusy(true)
        Thread {
            try {
                val live = LiveSearchCoordinator(
                    providers = listOf(SetupsMarketProvider(), MellonRacingProvider(), GitHubPublicProvider()),
                    onProgress = { updateStatus(it) },
                ).search(selection)
                val exact = (live as? LiveSearchResult.Exact)?.byStyle.orEmpty()
                val liveFailed = live is LiveSearchResult.TechnicalFailure
                val variants = EngineeringModel().generate(selection, liveFailed, exact)
                val files = SetupFileExporter(this).write(selection, variants)
                runOnUiThread {
                    latestFiles = files
                    result.text = report(selection, live, variants, files)
                    status.text = when (live) {
                        is LiveSearchResult.Exact -> "LIVE-EXACT geprüft · ${files.size} Setup(s) erstellt"
                        is LiveSearchResult.NoExact -> "KEIN LIVE-EXACT · ENGINEERING MODEL · ${files.size} Setup(s) erstellt"
                        is LiveSearchResult.TechnicalFailure -> "LIVE-SUCHE FEHLGESCHLAGEN NACH 3 VERSUCHEN · LIVE-UNVERIFIED · ${files.size} Setup(s) erstellt"
                    }
                    shareButton.visibility = View.VISIBLE
                    shareButton.isEnabled = true
                    setBusy(false)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "FEHLER: ${e.message ?: e.javaClass.simpleName}"
                    result.text = "Es wurde keine ungeprüfte Datei gespeichert. Bitte erneut versuchen."
                    setBusy(false)
                }
            }
        }.start()
    }

    private fun report(
        selection: SetupSelection,
        live: LiveSearchResult,
        variants: List<SetupVariant>,
        files: List<File>,
    ): String = buildString {
        appendLine("${selection.car.name}")
        appendLine("${selection.track.name} – ${selection.track.layout} · AC EVO ${selection.gameVersion}")
        appendLine("Fine-Tuning: ${selection.fineTuning.displayName}")
        appendLine("LIVE-Versuche: ${when (live) { is LiveSearchResult.Exact -> live.attempts; is LiveSearchResult.NoExact -> live.attempts; is LiveSearchResult.TechnicalFailure -> live.attempts }}")
        appendLine()
        variants.forEachIndexed { index, variant ->
            appendLine("${index + 1}. ${variant.style.displayName}")
            appendLine("   Herkunft: ${originLabel(variant.origin)}${variant.sourceLabel?.let { " · $it" } ?: ""}")
            if (variant.values.isNotEmpty()) {
                appendLine(variant.values.entries.joinToString("\n") { "   ${label(it.key)}: ${format(it.value)}" })
            }
            appendLine("   Datei: ${files[index].name}")
            appendLine()
        }
    }

    private fun originLabel(origin: SetupOrigin) = when (origin) {
        SetupOrigin.LIVE_EXACT -> "LIVE-EXACT"
        SetupOrigin.ENGINEERING_MODEL -> "ENGINEERING MODEL"
        SetupOrigin.LIVE_UNVERIFIED_ENGINEERING_MODEL -> "ENGINEERING MODEL · LIVE-UNVERIFIED"
    }

    private fun label(key: String): String = PARAMETER_LABELS[key] ?: key
    private fun format(value: Double): String = if (value % 1.0 == 0.0) value.toInt().toString() else String.format(Locale.ROOT, "%.3f", value).trimEnd('0').trimEnd('.')

    private fun setBusy(busy: Boolean) {
        generateButton.isEnabled = !busy
        carSpinner.isEnabled = !busy
        trackSpinner.isEnabled = !busy
        outputSpinner.isEnabled = !busy
        fineSpinner.isEnabled = !busy
        progress.visibility = if (busy) View.VISIBLE else View.GONE
        if (busy) {
            latestFiles = emptyList()
            shareButton.visibility = View.GONE
            shareButton.isEnabled = false
        }
    }

    private fun updateStatus(text: String) = runOnUiThread { status.text = text }

    private fun addSpinner(root: LinearLayout, label: String): Spinner {
        root.addView(TextView(this).apply {
            text = label.uppercase(Locale.GERMAN)
            setTextColor(yellow)
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(9), 0, dp(4))
        })
        return Spinner(this).apply {
            setBackgroundColor(surface)
            root.addView(this, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)))
        }
    }

    private inner class YellowAdapter(items: List<String>) :
        ArrayAdapter<String>(this@MainActivity, android.R.layout.simple_spinner_item, items) {
        init { setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View =
            style(super.getView(position, convertView, parent), yellow)
        override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View =
            style(super.getDropDownView(position, convertView, parent), Color.WHITE)
        private fun style(view: View, color: Int): View = view.apply {
            (this as? TextView)?.apply {
                setTextColor(color)
                textSize = 15f
                setBackgroundColor(surface)
                setPadding(dp(12), dp(8), dp(12), dp(8))
            }
        }
    }

    private fun marginParams(top: Int = 0, gravity: Int = Gravity.NO_GRAVITY) =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(top)
            this.gravity = gravity
        }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object {
        private val PARAMETER_LABELS = mapOf(
            "frontLeftTyrePressure" to "Reifendruck VL", "frontRightTyrePressure" to "Reifendruck VR",
            "rearLeftTyrePressure" to "Reifendruck HL", "rearRightTyrePressure" to "Reifendruck HR",
            "frontCamber" to "Sturz vorn", "rearCamber" to "Sturz hinten", "frontToe" to "Spur vorn", "rearToe" to "Spur hinten",
            "tc" to "TC", "tc2" to "TC2", "abs" to "ABS", "engineMap" to "Motor-Mapping", "fuel" to "Kraftstoff",
            "frontARB" to "Stabilisator vorn", "rearARB" to "Stabilisator hinten", "steerRatio" to "Lenkübersetzung",
            "brakeBias" to "Bremsbalance", "brakePressure" to "Bremsdruck", "diffPower" to "Differenzial Zug",
            "diffCoast" to "Differenzial Schub", "diffPreload" to "Differenzial Vorspannung",
            "frontSpringRate" to "Federrate vorn", "rearSpringRate" to "Federrate hinten",
            "frontBump" to "Druckstufe vorn", "frontRebound" to "Zugstufe vorn",
            "rearBump" to "Druckstufe hinten", "rearRebound" to "Zugstufe hinten",
            "frontRideHeight" to "Bodenfreiheit vorn", "rearRideHeight" to "Bodenfreiheit hinten",
            "frontWing" to "Flügel vorn", "rearWing" to "Flügel hinten",
        )
    }
}
