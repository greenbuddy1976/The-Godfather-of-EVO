package com.greenbuddy.acevosetupengineer.data

import android.content.Context
import com.greenbuddy.acevosetupengineer.domain.CarProfile
import com.greenbuddy.acevosetupengineer.domain.ParameterRange
import com.greenbuddy.acevosetupengineer.domain.TrackProfile
import org.json.JSONObject
import java.util.Locale

class InventoryRepository(private val context: Context) {
    fun loadCars(): List<CarProfile> {
        val names = context.assets.open("cars.csv").bufferedReader().useLines { lines ->
            lines.drop(1).mapNotNull { line ->
                val parts = line.split(',', limit = 4)
                if (parts.size < 3) null else parts[1] to parts[2]
            }.toMap()
        }
        val root = JSONObject(context.assets.open("setup-ranges.json").bufferedReader().use { it.readText() })
        return root.keys().asSequence().map { id ->
            val json = root.getJSONObject(id)
            val ranges = linkedMapOf<String, ParameterRange?>()
            json.keys().forEach { key ->
                ranges[key] = if (json.isNull(key)) null else json.getJSONObject(key).toRange()
            }
            CarProfile(id, names[id] ?: prettyName(id), ranges)
        }.sortedBy { it.name.lowercase(Locale.ROOT) }.toList()
    }

    fun loadTracks(): List<TrackProfile> = context.assets.open("tracks.csv").bufferedReader().useLines { lines ->
        lines.drop(1).mapNotNull { line ->
            val parts = line.split(',', limit = 5)
            if (parts.size < 5) null else trackProfile(
                id = parts[3],
                name = parts[1],
                layout = parts[2],
            )
        }.toList()
    }

    private fun JSONObject.toRange(): ParameterRange {
        val sourceMin = getDouble("min")
        val sourceMax = getDouble("max")
        val min = minOf(sourceMin, sourceMax)
        val max = maxOf(sourceMin, sourceMax)
        val step = optDouble("step", Double.NaN).takeIf { it.isFinite() && it > 0.0 }
            ?: inferStep(min, max)
        return ParameterRange(min, max, step)
    }

    private fun inferStep(min: Double, max: Double): Double {
        val span = max - min
        return when {
            span <= 0.1 -> 0.01
            span <= 1.0 -> 0.05
            span <= 20.0 -> 1.0
            span <= 200.0 -> 5.0
            span <= 2_000.0 -> 100.0
            else -> 1_000.0
        }
    }

    private fun trackProfile(id: String, name: String, layout: String): TrackProfile {
        val key = "$name $layout".lowercase(Locale.ROOT)
        val downforce = when {
            listOf("monza", "paul ricard").any(key::contains) -> 0.20
            listOf("spa", "silverstone", "suzuka", "watkins", "kyalami").any(key::contains) -> 0.63
            listOf("hungaroring", "brands hatch indy", "oulton", "donington").any(key::contains) -> 0.78
            else -> 0.53
        }
        val bumpiness = when {
            listOf("sebring", "nordschleife", "mount panorama", "oulton").any(key::contains) -> 0.88
            listOf("road atlanta", "brands hatch", "laguna seca").any(key::contains) -> 0.66
            else -> 0.38
        }
        val traction = when {
            listOf("monza", "red bull", "spa", "road atlanta").any(key::contains) -> 0.76
            listOf("hungaroring", "misano", "brands hatch indy").any(key::contains) -> 0.58
            else -> 0.66
        }
        val braking = when {
            listOf("monza", "mount panorama", "circuit of the americas", "paul ricard").any(key::contains) -> 0.88
            listOf("suzuka", "silverstone", "brands hatch").any(key::contains) -> 0.56
            else -> 0.70
        }
        val tyreStress = when {
            listOf("suzuka", "silverstone", "barcelona", "fuji").any(key::contains) -> 0.85
            listOf("monza", "brands hatch indy", "misano").any(key::contains) -> 0.50
            else -> 0.68
        }
        return TrackProfile(id, name, layout, downforce, bumpiness, traction, braking, tyreStress)
    }

    private fun prettyName(id: String): String = id.split('_').joinToString(" ") { token ->
        token.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.ROOT) else it.toString() }
    }
}
