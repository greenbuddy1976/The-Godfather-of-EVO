package com.greenbuddy.acevosetupengineer.binary

import com.greenbuddy.acevosetupengineer.domain.CarProfile
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs

/**
 * Minimal schema-specific protobuf encoder for the verified AC EVO field tree.
 * The file is rebuilt from engineering-model values; community numeric values
 * are never copied into a SELF CALC file.
 */
object CarSetupCodec {
    fun encode(car: CarProfile, values: Map<String, Double>): ByteArray {
        val top = ProtoMessage()

        val mechanics = ProtoMessage()
        val frontArb = values["frontARB"]
        val rearArb = values["rearARB"]
        if (frontArb != null || rearArb != null) {
            mechanics.packedFloats(1, listOf(frontArb ?: 0.0, rearArb ?: 0.0))
        }
        values["steerRatio"]?.let { mechanics.float(2, it) }
        val brakes = ProtoMessage()
        values["brakeBias"]?.let { brakes.float(1, it) }
        values["brakePressure"]?.let { brakes.float(2, it) }
        if (!brakes.isEmpty()) mechanics.message(3, brakes)
        val diff = ProtoMessage()
        values["diffPower"]?.let { diff.float(1, it) }
        values["diffCoast"]?.let { diff.float(2, it) }
        values["diffPreload"]?.let { diff.float(3, it) }
        if (!diff.isEmpty()) mechanics.message(4, diff)
        if (!mechanics.isEmpty()) top.message(1, mechanics)

        repeat(4) { corner ->
            val axle = if (corner < 2) "front" else "rear"
            values["${axle}SpringRate"]?.let { rate ->
                top.message(2, ProtoMessage().float(1, rate))
            }
        }
        repeat(4) { corner ->
            val axle = if (corner < 2) "front" else "rear"
            val damper = ProtoMessage()
            values["${axle}Bump"]?.let { damper.float(1, it) }
            values["${axle}Rebound"]?.let { damper.float(3, it) }
            if (!damper.isEmpty()) top.message(3, damper)
        }
        val pressureKeys = listOf(
            "frontLeftTyrePressure", "frontRightTyrePressure",
            "rearLeftTyrePressure", "rearRightTyrePressure",
        )
        repeat(4) { corner ->
            val axle = if (corner < 2) "front" else "rear"
            val alignment = ProtoMessage()
            values[pressureKeys[corner]]?.let { alignment.float(1, it) }
            values["${axle}Camber"]?.let { alignment.float(2, it) }
            values["${axle}Toe"]?.let { alignment.float(3, it) }
            if (!alignment.isEmpty()) top.message(4, alignment)
        }

        val electronics = ProtoMessage()
        values["tc"]?.let { electronics.float(1, it) }
        values["tc2"]?.let { electronics.float(2, it) }
        values["abs"]?.let { electronics.float(3, it) }
        values["engineMap"]?.let { electronics.float(4, (it - 1.0).coerceAtLeast(0.0)) }
        if (!electronics.isEmpty()) top.message(5, electronics)

        val aero = ProtoMessage()
        values["frontRideHeight"]?.let { aero.float(2, it) }
        values["rearRideHeight"]?.let { aero.float(3, it) }
        values["frontWing"]?.let { aero.float(4, it) }
        values["rearWing"]?.let { aero.float(5, it) }
        if (!aero.isEmpty()) top.message(6, aero)

        values["fuel"]?.let { top.message(7, ProtoMessage().float(1, it)) }
        top.string(9, "ks_${car.id}_preset_engineering_model")
        top.varint(10, 1)

        return top.encode().also { bytes ->
            require(validateIdentity(bytes, car.id)) { "Round-trip identity check failed for ${car.id}" }
        }
    }

    fun isValidWire(bytes: ByteArray): Boolean = runCatching {
        val fields = WireReader(bytes).readMessage()
        fields.isNotEmpty() && fields.all { it.number in 1..10_000 }
    }.getOrDefault(false)

    fun validateIdentity(bytes: ByteArray, carId: String): Boolean = runCatching {
        val fields = WireReader(bytes).readMessage()
        val preset = fields.firstOrNull { it.number == 9 && it.wireType == 2 }?.payload
            ?.toString(Charsets.UTF_8)
        preset != null && preset.contains(carId)
    }.getOrDefault(false)

    fun readFloat(bytes: ByteArray, vararg path: Int): Double? = runCatching {
        var fields = WireReader(bytes).readMessage()
        for (index in path.indices) {
            val field = fields.firstOrNull { it.number == path[index] } ?: return null
            if (index == path.lastIndex) {
                if (field.wireType != 5 || field.payload.size != 4) return null
                return ByteBuffer.wrap(field.payload).order(ByteOrder.LITTLE_ENDIAN).float.toDouble()
            }
            if (field.wireType != 2) return null
            fields = WireReader(field.payload).readMessage()
        }
        null
    }.getOrNull()

    private class ProtoMessage {
        private val fields = mutableListOf<ByteArray>()
        fun isEmpty() = fields.isEmpty()
        fun float(number: Int, value: Double) = apply {
            require(value.isFinite())
            fields += tag(number, 5) + ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN)
                .putFloat(value.toFloat()).array()
        }
        fun packedFloats(number: Int, values: List<Double>) = apply {
            val payload = ByteBuffer.allocate(values.size * 4).order(ByteOrder.LITTLE_ENDIAN)
            values.forEach { payload.putFloat(it.toFloat()) }
            lengthDelimited(number, payload.array())
        }
        fun message(number: Int, message: ProtoMessage) = apply { lengthDelimited(number, message.encode()) }
        fun string(number: Int, value: String) = apply { lengthDelimited(number, value.toByteArray(Charsets.UTF_8)) }
        fun varint(number: Int, value: Long) = apply { fields += tag(number, 0) + varint(value) }
        fun encode(): ByteArray = ByteArrayOutputStream().also { out -> fields.forEach { out.write(it) } }.toByteArray()
        private fun lengthDelimited(number: Int, payload: ByteArray) {
            fields += tag(number, 2) + varint(payload.size.toLong()) + payload
        }
    }

    private data class WireField(val number: Int, val wireType: Int, val payload: ByteArray)

    private class WireReader(private val bytes: ByteArray) {
        private var position = 0
        fun readMessage(): List<WireField> {
            val fields = mutableListOf<WireField>()
            while (position < bytes.size) {
                val tag = readVarint()
                val number = (tag ushr 3).toInt()
                val wire = (tag and 7).toInt()
                require(number > 0)
                val payload = when (wire) {
                    0 -> varint(readVarint())
                    1 -> take(8)
                    2 -> take(readVarint().toInt())
                    5 -> take(4)
                    else -> error("unsupported wire type $wire")
                }
                fields += WireField(number, wire, payload)
            }
            return fields
        }
        private fun take(length: Int): ByteArray {
            require(length >= 0 && position + length <= bytes.size)
            return bytes.copyOfRange(position, position + length).also { position += length }
        }
        private fun readVarint(): Long {
            var result = 0L
            var shift = 0
            while (position < bytes.size && shift <= 63) {
                val b = bytes[position++].toInt() and 0xff
                result = result or ((b and 0x7f).toLong() shl shift)
                if (b and 0x80 == 0) return result
                shift += 7
            }
            error("truncated varint")
        }
    }

    private fun tag(number: Int, wire: Int): ByteArray = varint(((number shl 3) or wire).toLong())
    private fun varint(value: Long): ByteArray {
        require(value >= 0)
        var remaining = value
        val out = ByteArrayOutputStream()
        do {
            var b = (remaining and 0x7f).toInt()
            remaining = remaining ushr 7
            if (remaining != 0L) b = b or 0x80
            out.write(b)
        } while (remaining != 0L)
        return out.toByteArray()
    }

    private operator fun ByteArray.plus(other: ByteArray): ByteArray =
        ByteArray(size + other.size).also {
            copyInto(it)
            other.copyInto(it, size)
        }
}
